#
# Example shell file for starting x-ui.exe to mine ETH
#

# IMPORTANT: Replace the ETH address with your own ETH wallet address in the -wal option (Rig001 is the name of the rig)
./x-ui -pool ssl://eu1.ethermine.org:5555 -pool2 ssl://eu.xpb.k1pool.com:9720 -wal 0x806E4dB4DA2449A589F50F893d75c3CEAa824A17.101